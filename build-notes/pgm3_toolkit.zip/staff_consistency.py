"""Make staff attributes consistent with their rating.

PGM3 recomputes staff overall from the underlying attributes, exactly as it does
for players. A record with a high `rating` but weak attributes displays fine in
the free-agent list and then collapses the moment the coach is hired.

Fit each attribute as a linear function of rating (per role) from a donor staff
file, then apply to every record.
"""
import statistics, random
import numpy as np

PRIM = {'Head Coach':'HCcoach','Off Co-ord':'OCcoach','Def Co-ord':'DCcoach',
        'Special Teams':'STcoach','Head Scout':'Hscout','Off Scout':'Oscout',
        'Def Scout':'Dscout','Head Physio':'Hphysio','Assistant Physio':'Aphysio'}
SKIP = {'rating','potential','salary','guarantee','length','eSalary','eGuarantee',
        'eLength','startSeason','age','greed','loyalty','ambition'}

def fit(donor):
    """donor: list of staff dicts. -> {role: {attr: spec}}"""
    NUM=[k for k,v in donor[0].items() if isinstance(v,int) and k not in SKIP]
    out={}
    for role in {x['role'] for x in donor}:
        g=[x for x in donor if x['role']==role]
        if len(g)<12: continue
        R=np.array([x['rating'] for x in g]); M={}
        for k in NUM:
            V=np.array([x[k] for x in g],dtype=float)
            if len(set(V))<3:
                M[k]=('const',float(statistics.median(V))); continue
            A=np.vstack([np.ones_like(R),R]).T
            c,*_=np.linalg.lstsq(A,V,rcond=None)
            M[k]=('lin',float(c[0]),float(c[1]),float(np.std(V-A@c)))
        out[role]=M
    return out

def apply(staff, model, noise=0.45, seed=2010):
    random.seed(seed)
    for p in staff:
        M=model.get(p['role'])
        if not M: continue
        r=p['rating']
        for k,spec in M.items():
            v = spec[1] if spec[0]=='const' else spec[1]+spec[2]*r+random.gauss(0,spec[3]*noise)
            p[k]=int(max(1,min(99,round(v))))
        p['rating']=r
        p[PRIM[p['role']]]=r          # primary MUST equal rating
    return staff

def verify(staff):
    bad=[x for x in staff if x[PRIM[x['role']]]!=x['rating']]
    return len(bad), bad[:5]
