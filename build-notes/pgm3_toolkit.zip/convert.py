import sys, json, random, uuid, collections, statistics
import re
sys.path.insert(0,'/home/claude/build')
from sources import load, norm, TEAMID
from positions import resolve

random.seed(2010)
BASE={'speed','burst','power','agility','jumping','stamina','injuryProne',
      'intelligence','vision','decisions','discipline'}
EXTRA={'QB':{'ballSecurity','skillMove','sPassAcc','mPassAcc','dPassAcc','throwOnRun','trucking','elusiveness','rushBlock'},
 'RB':{'ballSecurity','skillMove','trucking','elusiveness','rushBlock','passBlock','catching','routeRun','releaseLine'},
 'WR':{'ballSecurity','skillMove','trucking','elusiveness','rushBlock','passBlock','catching','routeRun','releaseLine'},
 'TE':{'ballSecurity','skillMove','trucking','elusiveness','rushBlock','passBlock','catching','routeRun','releaseLine'},
 'OT':{'rushBlock','passBlock','releaseLine'},'OG':{'rushBlock','passBlock','releaseLine'},
 'C':{'rushBlock','passBlock','releaseLine'},
 'DE':{'skillMove','releaseLine','tackle','blockShedding','ballStrip'},
 'DT':{'skillMove','releaseLine','tackle','blockShedding','ballStrip'},
 'OLB':{'skillMove','releaseLine','tackle','blockShedding','ballStrip'},
 'MLB':{'skillMove','releaseLine','tackle','blockShedding','manCover','zoneCover','ballStrip'},
 'CB':{'skillMove','releaseLine','tackle','blockShedding','manCover','zoneCover','ballStrip'},
 'S':{'skillMove','releaseLine','tackle','blockShedding','manCover','zoneCover','ballStrip'},
 'K':{'kickAccuracy'},'P':{'kickAccuracy'}}
# madden11 column -> pgm3 field
M11={'speed':'SPEED','burst':'ACCLERATION','power':'STRENGTH','agility':'AGILITY','jumping':'JUMPING',
 'stamina':'STAMINA','intelligence':'AWARENESS','ballSecurity':'CARRYING','sPassAcc':'THROW ACCURACY SHORT',
 'mPassAcc':'THROW ACCURACY MID','dPassAcc':'THROW ACCURACY DEEP','throwOnRun':'THROW ON RUN',
 'kickAccuracy':'KICK ACCURACY','rushBlock':'RUNBLOCK','passBlock':'PASSBLOCK','tackle':'TACKLE',
 'trucking':'TRUCKING','elusiveness':'ELUSIVENESS','vision':'BALL CARRIER VISION',
 'blockShedding':'BLOCK SHEDDING','manCover':'MAN COVERAGE','zoneCover':'ZONE COVERAGE',
 'routeRun':'ROUTE RUNNING','releaseLine':'RELEASE','catching':'CATCHING'}

def clamp(v,lo=1,hi=99):
    try: v=int(round(float(v)))
    except: return None
    return max(lo,min(hi,v))

APPEAR=None
def appearance_pool(ref):
    global APPEAR
    if APPEAR is None:
        APPEAR=[p['appearance'] for p in ref]
    return random.choice(APPEAR)

GROWTH=None
def growth_for(ref, pos, age, pot_gap):
    """Borrow a growthType array from a 2025 player at same position & similar age."""
    global GROWTH
    if GROWTH is None:
        GROWTH=collections.defaultdict(list)
        for p in ref: GROWTH[(p['position'], p['age'])].append(p['growthType'])
    for a in (age, age-1, age+1, age-2, age+2):
        if GROWTH[(pos,a)]: return random.choice(GROWTH[(pos,a)])
    allg=[g for v in GROWTH.values() for g in v]
    return random.choice(allg)

def build():
    pfr,m11,m12=load()
    ref=json.load(open('/mnt/user-data/uploads/PGMRoster2025-06-12_3.json'))
    refteam=[p for p in ref if p['teamID'] not in ('Rookie','Free Agent')]
    N34={t for t,v in pfr.items() if v['dfn']=='3-4'}
    # position-level medians from Madden11 for filling gaps
    med=collections.defaultdict(lambda: collections.defaultdict(list))
    out=[]; stats=collections.Counter()

    # pass 1: gather medians by pgm3 position from matched madden11 records
    prelim=[]
    for t,v in pfr.items():
        for p in v['players']:
            n=norm(p['player'].replace('*','').replace('+',''))
            a=m11.get((t,n)); b=m12.get(n)
            try: w=float(p.get('weight') or 0)
            except: w=0
            pos,psrc=resolve(p.get('pos'), a.get('POSITION') if a else None,
                             b.get('Position') if b else None, w, t in N34)
            if not pos: pos='OLB'; psrc='fallback'
            prelim.append((t,p,n,a,b,pos,psrc))
            if a:
                for f,col in M11.items():
                    val=clamp(a.get(col))
                    if val: med[pos][f].append(val)
    POSMED={pos:{f:int(statistics.median(v)) for f,v in d.items()} for pos,d in med.items()}

    for t,p,n,a,b,pos,psrc in prelim:
        fields=BASE|EXTRA[pos]
        rec={}
        # --- ratings
        for f in ['speed','burst','power','agility','jumping','stamina','intelligence','vision',
                  'decisions','discipline','injuryProne','ballSecurity','skillMove','sPassAcc',
                  'mPassAcc','dPassAcc','throwOnRun','kickAccuracy','rushBlock','passBlock','tackle',
                  'trucking','elusiveness','blockShedding','manCover','zoneCover','routeRun',
                  'releaseLine','catching','ballStrip']:
            if f not in fields: rec[f]=0; continue
            val=None
            if a and f in M11: val=clamp(a.get(M11[f]))
            if val is None and f=='injuryProne' and a:
                iv=clamp(a.get('INJURY'))
                val=100-iv if iv else None
            if val is None and f=='skillMove' and a:
                sm=[clamp(a.get('SPIN MOVE')),clamp(a.get('JUKE MOVE'))]
                sm=[x for x in sm if x]; val=int(sum(sm)/len(sm)) if sm else None
            if val is None and f=='ballStrip' and a: val=clamp(a.get('HITPOWER'))
            if val is None and f=='decisions' and a:
                d=[clamp(a.get('AWARENESS')),clamp(a.get('PLAY RECOGNITION'))]
                d=[x for x in d if x]; val=int(sum(d)/len(d)) if d else None
            if val is None and b:  # madden12 core six
                M12COL={'speed':'Speed','burst':'Acceleration','power':'Strength','agility':'Agility',
                        'intelligence':'Awareness','ballSecurity':'Carrying','stamina':'Stamina',
                        'trucking':'Trucking','catching':'Catching','jumping':'Jumping',
                        'elusiveness':'Elusiveness','routeRun':'Route Running','vision':'Ball Carrier Vision'}
                if f in M12COL: val=clamp(b.get(M12COL[f]))
            if val is None: val=POSMED.get(pos,{}).get(f, 60)
            rec[f]=val
        if a and rec.get('injuryProne'):
            iv=clamp(a.get('INJURY'))
            if iv: rec['injuryProne']=max(1,min(99,100-iv))
        rec['position']=pos
        rec['teamID']=TEAMID[t]
        rec['forename'],rec['surname']=p['player'].replace('*','').replace('+','').strip().split(' ',1)[0], \
                                        ' '.join(p['player'].replace('*','').replace('+','').strip().split(' ')[1:]) or p['player']
        stats['m11' if a else ('m12' if b else 'derived')]+=1
        stats['pos_'+psrc]+=1
        out.append((rec,p,a,b,t))
    return out, POSMED, refteam, pfr

CAP2010_REF=123_000_000   # 2009 cap (2010 was uncapped)
CAP_PGM3=280_000_000
SCALE=CAP_PGM3/CAP2010_REF

def finish(out, POSMED, refteam, pfr):
    """Add rating, potential, contracts, personality, growth, appearance, iden."""
    # rating: prefer Madden11 OVERALL; else derive from AV + games started
    avs=[]
    for rec,p,a,b,t in out:
        try: avs.append(float(p.get('av') or 0))
        except: pass
    players=[]
    for rec,p,a,b,t in out:
        try: av=float(p.get('av') or 0)
        except: av=0
        try: gs=int(p.get('gs') or 0)
        except: gs=0
        try: g=int(p.get('g') or 0)
        except: g=0
        try: age=int(float(p.get('age') or 26))
        except: age=26
        # ---- rating
        if a is not None:
            rating=clamp(a.get('OVERALL RATING')) or 65
        elif b is not None and b.get('Overall'):
            rating=clamp(b.get('Overall')) or 65
        else:
            # derive: AV and starts are the signal
            rating=52 + min(26, av*2.0) + min(8, gs*0.5)
            if g==0: rating=48
            rating=int(max(40,min(88,rating)))
        # ---- potential: ceiling only, shrinks hard with age
        if age<=21: cap=16
        elif age<=23: cap=13
        elif age<=25: cap=8
        elif age<=26: cap=4
        elif age<=28: cap=2
        else: cap=0
        head=0
        if cap:
            # young + productive = more headroom
            score=min(1.0,(av/12.0)*0.6 + (gs/16.0)*0.4)
            head=int(round(cap*(0.35+0.65*score)*random.uniform(0.7,1.15)))
            head=max(0,min(cap,head))
        potential=min(99, rating+head)
        # ---- contracts
        exp=p.get('experience','')
        try: yrs=0 if exp in ('Rook','') else int(exp)
        except: yrs=0
        rookie_deal = yrs<=3
        base = rating
        if base>=88:  sal=random.uniform(9e6,24e6)
        elif base>=82: sal=random.uniform(4e6,11e6)
        elif base>=76: sal=random.uniform(1.5e6,6e6)
        elif base>=70: sal=random.uniform(0.8e6,2.5e6)
        else:          sal=random.uniform(0.5e6,1.1e6)
        if rookie_deal: sal=min(sal, 3.4e6)*random.uniform(0.45,0.9)
        salary=int(round(sal/100000)*100000)
        length=random.choice([1,1,2,2,3,3,4]) if not rookie_deal else random.choice([1,2,3,4])
        guarantee=int(round(salary*random.uniform(0.0,0.8)/100000)*100000)
        # ---- personality (LOW<30, MED 40-70, HIGH>70)
        def trait():
            r=random.random()
            return random.randint(8,29) if r<0.28 else (random.randint(40,69) if r<0.72 else random.randint(72,96))
        # ---- draft
        di=(p.get('draft_info') or '')
        m=re.search(r'(\d+)(?:st|nd|rd|th) round.*?(\d+)(?:st|nd|rd|th) overall.*?(\d{4})', di)
        if m: dnum=min(224,int(m.group(2))); dseason=int(m.group(3))
        else:
            m2=re.search(r'(\d{4})', di)
            dnum=224; dseason=int(m2.group(1)) if m2 else 2010-max(0,yrs)
        rec.update({
            'rating':rating,'potential':potential,'age':age,
            'salary':salary,'guarantee':guarantee,'length':length,
            'eSalary':int(salary*random.uniform(1.1,2.2)/100000)*100000,
            'eGuarantee':int(guarantee*random.uniform(1.0,2.0)/100000)*100000,
            'eLength':random.choice([1,2,2,3,3,4]),
            'greed':trait(),'loyalty':trait(),'ambition':trait(),
            'draftNum':dnum,'draftSeason':dseason,
            'teamNum':int(p.get('uniform_number') or 0) if str(p.get('uniform_number') or '').isdigit() else 0,
            'iden':str(uuid.uuid4()).upper(),
            'appearance':appearance_pool(refteam),
            'growthType':growth_for(refteam, rec['position'], age, potential-rating),
        })
        players.append(rec)
    return players
