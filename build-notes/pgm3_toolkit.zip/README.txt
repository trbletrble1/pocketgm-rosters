PGM3 build toolkit — attach alongside PGM3_BUILD_NOTES.md

weights.json          Fitted position-weighted OVR coefficients. CRITICAL — the
                      game recomputes overall from attributes, and this is how
                      you make it land on the right number.
                      {position: [attr_names, coefs]}, last coef = intercept.
                      predicted = sum(player[attr]*coef) + intercept

positions.py          PFR / Madden position codes -> PGM3 vocabulary.
sources.py            Loaders for Madden sheets and PFR pages, name normaliser,
                      team ID map, alias fixes.
convert.py            Assembles player records end to end.

scouting_from_drafts.py   Derives team scouting ratings from real draft
                      outcomes vs pick position. Reusable for any year — feed it
                      the 5 draft classes BEFORE the target season.

staff_real_dist.json  Per-role supporting-attribute ratios (e.g. HCcoachDev is
                      ~0.99x HCcoach). Ratios are structural and reusable. The
                      rating distributions in this file came from a USER-MADE
                      roster — do not treat them as how the game behaves.

coachmodel.json       2010 coach rating model output. Worked example.
avail_coaches.py      2010 free-agent coach candidates from PFR's all-time
                      index, with career/playoff records. Shows the shape.

Regenerate per year: skin/hair extractions, contract data, CBA minimums.
