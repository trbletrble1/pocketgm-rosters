PGM3 build toolkit — attach alongside PGM3_BUILD_NOTES.md

weights.json    Fitted position-weighted OVR coefficients. CRITICAL — the game
                recomputes overall from attributes, and this is how you make it
                land on the right number. Format: {position: [attr_names, coefs]}
                where the last coef is the intercept.
                predicted = sum(player[attr] * coef) + intercept

positions.py    Maps PFR / Madden position codes to PGM3's vocabulary.
sources.py      Loaders for Madden spreadsheets and PFR pages, name normaliser,
                team ID map, alias fixes.
convert.py      Assembles player records end to end.

coachmodel.json Coach rating model output from the 2010 build — raw scores per
                head coach plus per-team offensive/defensive unit SRS z-scores.
                Rebuild for a new year; kept as a worked example.

avail_coaches.py  Free-agent coach candidates pulled from PFR's all-time index,
                  with career and playoff records. Year-specific; shows the shape.

Not included (year-specific, regenerate): skin/hair extractions, OTC season data,
CBA minimum schedule.
