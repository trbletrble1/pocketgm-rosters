import json, xlrd, openpyxl, glob, re, unicodedata

ALIAS={'gregory toler':'greg toler','steve johnson':'stevie johnson','zach follett':'zack follett',
'zac diles':'zach diles','anthony herrara':'anthony herrera','antonie winfield':'antoine winfield',
'brian robinson':'brian robison','tony hargrove':'anthony hargrove','william beatty':'will beatty',
'matthew slauson':'matt slauson','ronald bartell':'ron bartell','stylez white':'stylez g white'}

def norm(s):
    s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode()
    s=s.lower().replace('.','').replace("'",'').replace('-',' ')
    s=re.sub(r'\b(jr|sr|ii|iii|iv|v)\b','',s)
    s=' '.join(s.split())
    return ALIAS.get(s,s)

TEAMID={'Arizona_Cardinals':'ARI','Atlanta_Falcons':'ATL','Baltimore_Ravens':'BAL','Buffalo_Bills':'BUF',
'Carolina_Panthers':'CAR','Chicago_Bears':'CHI','Cincinnati_Bengals':'CIN','Cleveland_Browns':'CLE',
'Dallas_Cowboys':'DAL','Denver_Broncos':'DEN','Detroit_Lions':'DET','Green_Bay_Packers':'GB',
'Houston_Texans':'HOU','Indianapolis_Colts':'IND','Jacksonville_Jaguars':'JAX','Kansas_City_Chiefs':'KC',
'Miami_Dolphins':'MIA','Minnesota_Vikings':'MIN','New_England_Patriots':'NE','New_Orleans_Saints':'NO',
'New_York_Giants':'NYG','New_York_Jets':'NYJ','Oakland_Raiders':'LV','Philadelphia_Eagles':'PHI',
'Pittsburgh_Steelers':'PIT','San_Diego_Chargers':'LAC','San_Francisco_49ers':'SF','Seattle_Seahawks':'SEA',
'St._Louis_Rams':'LAR','Tampa_Bay_Buccaneers':'TB','Tennessee_Titans':'TEN','Washington_Redskins':'WAS'}

def load(base='/home/claude'):
    pfr=json.load(open(f'{base}/pfr2010.json'))
    for t in pfr:
        pfr[t]['players']=[p for p in pfr[t]['players'] if not p['player'].startswith('Team Total')]
    keys=sorted(f.split('/')[-1].replace('.xls','') for f in glob.glob(f'{base}/m11/*.xls'))
    m2p=dict(zip(keys,sorted(pfr)))
    m11={}
    for k in keys:
        s=xlrd.open_workbook(f'{base}/m11/{k}.xls').sheet_by_index(0)
        hdr=[str(s.cell_value(0,c)).strip().replace('\n',' ') for c in range(s.ncols)]
        ix={h:i for i,h in enumerate(hdr)}
        for r in range(1,s.nrows):
            g=lambda h: s.cell_value(r,ix[h]) if h in ix else None
            m11[(m2p[k],norm(f"{g('FIRST NAME')} {g('LAST NAME')}"))]={h:g(h) for h in hdr}
    m12={}
    for f in sorted(glob.glob(f'{base}/m12/*.xlsx')):
        wb=openpyxl.load_workbook(f,read_only=True); ws=wb[wb.sheetnames[0]]
        rows=list(ws.iter_rows(values_only=True)); wb.close()
        hdr=[str(c).strip().replace('\n',' ') if c else '' for c in rows[0]]
        ix={h:i for i,h in enumerate(hdr)}
        for r in rows[1:]:
            if not r or not r[ix['Name']]: continue
            m12.setdefault(norm(r[ix['Name']]), {h:r[ix[h]] for h in hdr if h})
    return pfr, m11, m12
