"""Derive team scouting ratings from real draft performance.
Reusable: point at the 5 draft classes preceding the target season."""
import json, collections, statistics
import numpy as np

OFF={'QB','RB','FB','WR','TE','T','G','C','OL','OT','OG'}
DEF={'DE','DT','NT','LB','ILB','OLB','MLB','CB','S','DB','SS','FS','DL'}
TEAMMAP={'GNB':'GB','KAN':'KC','NWE':'NE','NOR':'NO','SFO':'SF','TAM':'TB',
         'SDG':'LAC','STL':'LAR','OAK':'LV','RAM':'LAR','RAI':'LV'}

def team_draft_residuals(drafts):
    """drafts: {year: [pick dicts with draft_pick, career_av, team, pos]}"""
    picks=[]
    for y,rows in drafts.items():
        for r in rows:
            try: p=int(r['draft_pick']); av=float(r['career_av'] or 0)
            except: continue
            picks.append({'pick':p,'av':av,'team':r['team'],'pos':(r.get('pos') or '').strip()})
    X=np.array([[1,np.log(p['pick'])] for p in picks]); Y=np.array([p['av'] for p in picks])
    coef,*_=np.linalg.lstsq(X,Y,rcond=None)
    agg=collections.defaultdict(lambda:{'all':[],'off':[],'def':[]})
    for p in picks:
        resid=p['av']-(coef[0]+coef[1]*np.log(p['pick']))
        side='off' if p['pos'] in OFF else ('def' if p['pos'] in DEF else 'other')
        t=TEAMMAP.get(p['team'],p['team'])
        agg[t]['all'].append(resid)
        if side!='other': agg[t][side].append(resid)
    return agg

def rating(agg, team, side, pool_mean, pool_sd, floor=55, ceil=92):
    v=agg.get(team,{}).get(side,[])
    if len(v)<4: return None
    z=(statistics.mean(v)-pool_mean)/pool_sd
    z*= len(v)/(len(v)+8)                 # shrink small samples
    return int(round(max(floor,min(ceil, 72+z*9))))

ROLE_SIDE={'Head Scout':'all','Off Scout':'off','Def Scout':'def'}
