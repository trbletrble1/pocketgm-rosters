# PFR specific codes -> PGM3
PFR_MAP={'QB':'QB','RB':'RB','FB':'RB','WR':'WR','TE':'TE',
 'T':'OT','LT':'OT','RT':'OT','G':'OG','LG':'OG','RG':'OG','C':'C','LS':'C',
 'DE':'DE','LDE':'DE','RDE':'DE','DT':'DT','LDT':'DT','RDT':'DT','NT':'DT',
 'MLB':'MLB','LILB':'MLB','RILB':'MLB','LLB':'OLB','RLB':'OLB','LOLB':'OLB','ROLB':'OLB',
 'CB':'CB','LCB':'CB','RCB':'CB','S':'S','FS':'S','SS':'S','K':'K','P':'P'}
# Madden position vocab -> PGM3
MAD_MAP={'QB':'QB','HB':'RB','FB':'RB','WR':'WR','TE':'TE','LT':'OT','RT':'OT',
 'LG':'OG','RG':'OG','C':'C','LE':'DE','RE':'DE','DT':'DT','LOLB':'OLB','ROLB':'OLB',
 'MLB':'MLB','CB':'CB','FS':'S','SS':'S','K':'K','P':'P','DE':'DE','OLB':'OLB','S':'S','G':'OG','T':'OT'}

def resolve(pfr_pos, mad11_pos, mad12_pos, weight, is34):
    """Return (pgm3_position, source) — most specific source wins."""
    p=(pfr_pos or '').strip()
    # 1. PFR specific code (starters + anyone with an alignment)
    if p in PFR_MAP and p not in ('DB','LB',''):
        pos=PFR_MAP[p]
        # 3-4 ends listed as LDE/RDE are interior in PGM3 terms if heavy
        if is34 and pos=='DE' and weight and weight>=295: return 'DT','pfr+34'
        return pos,'pfr'
    # 2. Madden 11 (real position, position-specific)
    if mad11_pos and mad11_pos in MAD_MAP: return MAD_MAP[mad11_pos],'m11'
    # 3. Madden 12
    if mad12_pos and mad12_pos in MAD_MAP: return MAD_MAP[mad12_pos],'m12'
    # 4. last resort: split ambiguous by weight
    if p=='DB':  return ('S' if weight and weight>=205 else 'CB'),'weight'
    if p=='LB':  return ('DE' if weight and weight>=255 and is34 else ('MLB' if weight and weight<245 else 'OLB')),'weight'
    return None,'unresolved'
